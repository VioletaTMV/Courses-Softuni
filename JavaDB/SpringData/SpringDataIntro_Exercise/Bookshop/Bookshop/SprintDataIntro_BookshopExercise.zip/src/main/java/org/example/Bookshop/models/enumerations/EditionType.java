package org.example.Bookshop.models.enumerations;

public enum EditionType {

    NORMAL, PROMO, GOLD
}
