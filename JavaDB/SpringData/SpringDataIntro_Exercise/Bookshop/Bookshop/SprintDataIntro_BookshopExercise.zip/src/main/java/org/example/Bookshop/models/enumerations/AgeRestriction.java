package org.example.Bookshop.models.enumerations;

public enum AgeRestriction {

    MINOR, TEEN, ADULT
}
