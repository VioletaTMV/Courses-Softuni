package org.example.Bookshop.constants;

public class FilePath {

    public final static String PATH_BOOKS_FILE = "src\\main\\resources\\dbContent\\books.txt";
    public final static String PATH_AUTHORS_FILE = "src\\main\\resources\\dbContent\\authors.txt";
    public final static String PATH_CATEGORIES_FILE = "src\\main\\resources\\dbContent\\categories.txt";

}
